﻿#include "mylib.h"

Studentas ivestiNaujaStudenta() {
    string vardas, pavarde;
    vector<int> pazymiai(7);
    int egzaminas;
    char skaiciavimoStrategija;

    cout << "Iveskite studento varda: ";
    cin >> vardas;

    cout << "Iveskite studento pavarde: ";
    cin >> pavarde;

    cout << "Iveskite 7 namu darbu pazymius:\n";
    for (int i = 0; i < 7; ++i) {
        cout << "ND" << (i + 1) << ": ";
        cin >> pazymiai[i];
    }

    cout << "Iveskite egzamino pazymi: ";
    cin >> egzaminas;

    cout << "Kaip norite skaiciuoti galutini bala? (v - vidurkis, m - mediana): ";
    cin >> skaiciavimoStrategija;

    if (skaiciavimoStrategija != 'v' && skaiciavimoStrategija != 'm') {
        cout << "Neteisinga strategija. Naudojamas vidurkis (v)." << endl;
        skaiciavimoStrategija = 'v';
    }

    Studentas naujasStudentas(vardas, pavarde, pazymiai, egzaminas, skaiciavimoStrategija);
    return naujasStudentas;
}

// Function to generate student data files
template <typename Container>
void generateStudentFile(int irasuKiekis, const string& failoPavadinimas) {
    ofstream failas(failoPavadinimas);
    if (!failas.is_open()) {
        cout << "Nepavyko sukurti failo " << failoPavadinimas << endl;
        return;
    }

    failas << "Vardas Pavarde ";
    for (int i = 1; i <= 7; ++i) {
        failas << "ND" << i << " ";
    }
    failas << "Egzaminas" << endl;

    for (int i = 0; i < irasuKiekis; ++i) {
        failas << "Vardas" << i << " Pavarde" << i << " ";
        for (int j = 0; j < 7; ++j) {
            failas << rand() % 10 + 1 << " ";
        }
        failas << rand() % 10 + 1 << endl;
    }

    failas.close();
}

// Function to sort containers other than list
template <typename Container>
typename std::enable_if<!std::is_same<Container, list<Studentas>>::value>::type
sortContainer(Container& container) {
    std::sort(container.begin(), container.end(), [](const Studentas& a, const Studentas& b) {
        return a.gautiGalutiniBala() > b.gautiGalutiniBala();
        });
}

// Overload for list
void sortContainer(list<Studentas>& container) {
    container.sort([](const Studentas& a, const Studentas& b) {
        return a.gautiGalutiniBala() > b.gautiGalutiniBala();
        });
}

// First sorting strategy: create two new containers
template <typename Container>
void rusiavimasStudentuPirmas(Container& studentuGrupe, Container& vargsiukai, Container& kietiakiai) {

    std::for_each(studentuGrupe.begin(), studentuGrupe.end(), [](Studentas& s) {
        if (s.gautiSkaiciavimoStrategija() == 'v') {
            s.skaiciuotiGalutiniVidurki();
        }
        else {
            s.skaiciuotiGalutiniMediana();
        }
        });

    std::copy_if(studentuGrupe.begin(), studentuGrupe.end(), std::back_inserter(vargsiukai),
        [](const Studentas& s) { return s.gautiGalutiniBala() < 5.0; });

    std::copy_if(studentuGrupe.begin(), studentuGrupe.end(), std::back_inserter(kietiakiai),
        [](const Studentas& s) { return s.gautiGalutiniBala() >= 5.0; });

    sortContainer(vargsiukai);
    sortContainer(kietiakiai);
}

// Second sorting strategy: modify the original container
template <typename Container>
typename std::enable_if<!std::is_same<Container, std::list<Studentas>>::value>::type
rusiavimasStudentuAntras(Container& studentuGrupe, Container& vargsiukai) {

    std::for_each(studentuGrupe.begin(), studentuGrupe.end(), [](Studentas& s) {
        if (s.gautiSkaiciavimoStrategija() == 'v') {
            s.skaiciuotiGalutiniVidurki();
        }
        else {
            s.skaiciuotiGalutiniMediana();
        }
        });

    auto partitionPoint = std::stable_partition(studentuGrupe.begin(), studentuGrupe.end(),
        [](const Studentas& s) { return s.gautiGalutiniBala() >= 5.0; });

    vargsiukai.insert(vargsiukai.end(), partitionPoint, studentuGrupe.end());

    studentuGrupe.erase(partitionPoint, studentuGrupe.end());

    sortContainer(vargsiukai);
    sortContainer(studentuGrupe);
}

// Overload for list
void rusiavimasStudentuAntras(std::list<Studentas>& studentuGrupe, std::list<Studentas>& vargsiukai) {

    std::for_each(studentuGrupe.begin(), studentuGrupe.end(), [](Studentas& s) {
        if (s.gautiSkaiciavimoStrategija() == 'v') {
            s.skaiciuotiGalutiniVidurki();
        }
        else {
            s.skaiciuotiGalutiniMediana();
        }
        });

    auto it = studentuGrupe.begin();
    while (it != studentuGrupe.end()) {
        if (it->gautiGalutiniBala() < 5.0) {
            auto toMove = it++;
            vargsiukai.splice(vargsiukai.end(), studentuGrupe, toMove);
        }
        else {
            ++it;
        }
    }

    sortContainer(vargsiukai);
    sortContainer(studentuGrupe);
}

// Function to output data to files (first strategy)
template <typename Container>
void isvedimasIFailus(const Container& vargsiukai, const Container& kietiakiai) {
    ofstream vargsiukuFailas("vargsiukai.txt");
    ofstream kietiakiuFailas("kietiakiai.txt");

    vargsiukuFailas << left << setw(15) << "Vardas" << setw(15) << "Pavarde" << setw(20) << "Galutinis balas" << endl;
    vargsiukuFailas << "--------------------------------------------------" << endl;

    kietiakiuFailas << left << setw(15) << "Vardas" << setw(15) << "Pavarde" << setw(20) << "Galutinis balas" << endl;
    kietiakiuFailas << "--------------------------------------------------" << endl;

    for (const auto& studentas : vargsiukai) {
        vargsiukuFailas << left << setw(15) << studentas.gautiVarda()
            << setw(15) << studentas.gautiPavarde()
            << right << setw(20) << fixed << setprecision(2) << studentas.gautiGalutiniBala()
            << endl;
    }

    for (const auto& studentas : kietiakiai) {
        kietiakiuFailas << left << setw(15) << studentas.gautiVarda()
            << setw(15) << studentas.gautiPavarde()
            << right << setw(20) << fixed << setprecision(2) << studentas.gautiGalutiniBala()
            << endl;
    }

    vargsiukuFailas.close();
    kietiakiuFailas.close();

    cout << "Is viso studentu: " << vargsiukai.size() + kietiakiai.size() << endl;
    cout << "Vargsiukai: " << vargsiukai.size() << ", Kietiakiai: " << kietiakiai.size() << endl;
}

// Function to output data to files (second strategy)
template <typename Container>
void isvedimasIFailusAntras(const Container& vargsiukai, const Container& studentuGrupe) {
    ofstream vargsiukuFailas("vargsiukai.txt");
    ofstream kietiakiuFailas("kietiakiai.txt");

    vargsiukuFailas << left << setw(15) << "Vardas" << setw(15) << "Pavarde" << setw(20) << "Galutinis balas" << endl;
    vargsiukuFailas << "--------------------------------------------------" << endl;

    kietiakiuFailas << left << setw(15) << "Vardas" << setw(15) << "Pavarde" << setw(20) << "Galutinis balas" << endl;
    kietiakiuFailas << "--------------------------------------------------" << endl;

    for (const auto& studentas : vargsiukai) {
        vargsiukuFailas << left << setw(15) << studentas.gautiVarda()
            << setw(15) << studentas.gautiPavarde()
            << right << setw(20) << fixed << setprecision(2) << studentas.gautiGalutiniBala()
            << endl;
    }

    for (const auto& studentas : studentuGrupe) {
        kietiakiuFailas << left << setw(15) << studentas.gautiVarda()
            << setw(15) << studentas.gautiPavarde()
            << right << setw(20) << fixed << setprecision(2) << studentas.gautiGalutiniBala()
            << endl;
    }

    vargsiukuFailas.close();
    kietiakiuFailas.close();

    cout << "Is viso studentu: " << vargsiukai.size() + studentuGrupe.size() << endl;
    cout << "Vargsiukai: " << vargsiukai.size() << ", Kietiakiai: " << studentuGrupe.size() << endl;
}

// Main program function
template <typename Container>
void runProgram() {
    Container studentuGrupe;
    string eilute;
    int pasirinkimas = 0;

    cout << "Pasirinkite, koki faila norite sugeneruoti:\n";
    cout << "1 - 1000 studentu\n";
    cout << "2 - 10000 studentu\n";
    cout << "3 - 100000 studentu\n";
    cout << "4 - 1000000 studentu\n";
    cout << "5 - 10000000 studentu\n";
    cout << "Iveskite pasirinkima (1-5): ";
    cin >> pasirinkimas;

    int irasuKiekis = 0;
    string failoPavadinimas;
    switch (pasirinkimas) {
    case 1:
        irasuKiekis = 1000;
        failoPavadinimas = "studentai_1000.txt";
        break;
    case 2:
        irasuKiekis = 10000;
        failoPavadinimas = "studentai_10000.txt";
        break;
    case 3:
        irasuKiekis = 100000;
        failoPavadinimas = "studentai_100000.txt";
        break;
    case 4:
        irasuKiekis = 1000000;
        failoPavadinimas = "studentai_1000000.txt";
        break;
    case 5:
        irasuKiekis = 10000000;
        failoPavadinimas = "studentai_10000000.txt";
        break;
    default:
        cout << "Neteisingas pasirinkimas, generuojama 1000 studentu." << endl;
        irasuKiekis = 1000;
        failoPavadinimas = "studentai_1000.txt";
        break;
    }

    // Generate the student file
    generateStudentFile<Container>(irasuKiekis, failoPavadinimas);

    auto start_nuskaitymas = high_resolution_clock::now();

    ifstream failas(failoPavadinimas);
    if (failas.is_open()) {
        getline(failas, eilute); // Skip header line
        while (getline(failas, eilute)) {
            string vardas, pavarde;
            vector<int> pazymiai;
            int egzaminas;

            istringstream iss(eilute);
            iss >> vardas >> pavarde;

            int pazymys;
            while (iss >> pazymys) {
                pazymiai.push_back(pazymys);
            }

            egzaminas = pazymiai.back();
            pazymiai.pop_back();

            Studentas naujasStudentas(vardas, pavarde, pazymiai, egzaminas, 'v');
            studentuGrupe.push_back(naujasStudentas);
        }
        failas.close();
    }
    else {
        cout << "Nepavyko atidaryti failo " << failoPavadinimas << endl;
    }

    auto end_nuskaitymas = high_resolution_clock::now();
    duration<double> trukme_nuskaitymas = end_nuskaitymas - start_nuskaitymas;
    cout << "Duomenu nuskaitymo trukme: " << trukme_nuskaitymas.count() << " sekundziu\n";

    char ivestiNauja;
    cout << "Ar norite ivesti nauja studenta? (y/n): ";
    cin >> ivestiNauja;

    if (ivestiNauja == 'y' || ivestiNauja == 'Y') {
        Studentas naujasStudentas = ivestiNaujaStudenta();
        studentuGrupe.push_back(naujasStudentas);
    }

    int strategijosPasirinkimas;
    cout << "Pasirinkite rusiavimo strategija:\n";
    cout << "1 - Pirmoji strategija (du nauji konteineriai)\n";
    cout << "2 - Antra strategija (vienas naujas konteineris, trynimas is pradinio)\n";
    cout << "Iveskite pasirinkima (1 arba 2): ";
    cin >> strategijosPasirinkimas;

    if (strategijosPasirinkimas == 1) {
        auto start_rusiavimas = high_resolution_clock::now();

        Container vargsiukai;
        Container kietiakiai;
        rusiavimasStudentuPirmas(studentuGrupe, vargsiukai, kietiakiai);

        auto end_rusiavimas = high_resolution_clock::now();
        duration<double> trukme_rusiavimas = end_rusiavimas - start_rusiavimas;
        cout << "Studentu rusiavimo trukme: " << trukme_rusiavimas.count() << " sekundziu\n";

        auto start_isvedimas = high_resolution_clock::now();

        isvedimasIFailus(vargsiukai, kietiakiai);

        auto end_isvedimas = high_resolution_clock::now();
        duration<double> trukme_isvedimas = end_isvedimas - start_isvedimas;
        cout << "Duomenu isvedimo i failus trukme: " << trukme_isvedimas.count() << " sekundziu\n";
    }
    else if (strategijosPasirinkimas == 2) {
        auto start_rusiavimas = high_resolution_clock::now();

        Container vargsiukai;
        rusiavimasStudentuAntras(studentuGrupe, vargsiukai);

        auto end_rusiavimas = high_resolution_clock::now();
        duration<double> trukme_rusiavimas = end_rusiavimas - start_rusiavimas;
        cout << "Studentu rusiavimo trukme: " << trukme_rusiavimas.count() << " sekundziu\n";

        auto start_isvedimas = high_resolution_clock::now();

        isvedimasIFailusAntras(vargsiukai, studentuGrupe);

        auto end_isvedimas = high_resolution_clock::now();
        duration<double> trukme_isvedimas = end_isvedimas - start_isvedimas;
        cout << "Duomenu isvedimo i failus trukme: " << trukme_isvedimas.count() << " sekundziu\n";
    }
    else {
        cout << "Neteisingas strategijos pasirinkimas." << endl;
    }
}

int main() {
    srand(static_cast<unsigned int>(time(0)));
    cout << "Koki konteineri noretumete patikrinti, Vector, List, Deque: ";
    string containerChoice;
    cin >> containerChoice;

    if (containerChoice == "Vector" || containerChoice == "vector") {
        runProgram<vector<Studentas>>();
    }
    else if (containerChoice == "List" || containerChoice == "list") {
        runProgram<list<Studentas>>();
    }
    else if (containerChoice == "Deque" || containerChoice == "deque") {
        runProgram<deque<Studentas>>();
    }
    else {
        cout << "Neteisingas pasirinkimas, naudojamas vector" << endl;
        runProgram<vector<Studentas>>();
    }

    return 0;
}
